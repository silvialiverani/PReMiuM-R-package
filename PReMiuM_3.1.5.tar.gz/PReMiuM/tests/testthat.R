library(testthat)
library(PReMiuM)

test_check("PReMiuM")
