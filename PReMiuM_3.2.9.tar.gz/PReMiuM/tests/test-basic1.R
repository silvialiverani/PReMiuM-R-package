library(testthat)
library(PReMiuM)

# this function should not be called directly
# it is meant to be called by R CMD check only
# use devtools::test() if need to call directly
test_check("PReMiuM")

